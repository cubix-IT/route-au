# Unplanned Escapes — Session Plan

## ⚠️ PERMANENT RULE — NO GOOGLE API, NO PAID APIS
Google Places caused A$1,992 bill. Never use any paid API on this project.
Free stack only: Overpass API (OSM) · Wikipedia · Supabase · Vercel Hobby · Resend · Claude API (summaries only)

## Free Data Top-Up (enrichment cron)
- Schedule: `0 1 * * *` (UTC) = 11am AEST daily
- Processes 8 destinations per run, cycles all 131 in ~16 days
- Radius: 2km inner Melbourne (<15km CBD) / 10km regional / 20km rural
- Email: only sends once per full cycle (~16 days), not per batch
- Description generation: OSM tag → Wikipedia → Claude Haiku (batched per destination)

## Architecture
- Frontend: React + Vite + TypeScript, deployed on Vercel Hobby
- Database: Supabase (Sydney) — activities, food_places, nature_spots, accommodation, fuel
- Crons: enrich (daily), fuel (daily 3am AEST), summaries (weekly), limits (Monday 9am AEST)
- Email: Resend (free tier, send-only key) — only used for enrichment cycle complete + limits alerts
- Status page: /api/status (HTML dashboard) — cron health, data counts, enrichment freshness per region

## Current State (2026-06-01)
### Data
- 131 sub-destinations (merged 8 duplicate/close pairs this session)
- 890+ activities, 1,568+ food places, 357+ nature spots — all with lat/lng + Claude descriptions
- All destinations enriched with tiered radius

### What was done this session
- Fixed activities upsert (cost 'Free' → 'free' CHECK constraint)
- Fixed lat/lng missing ('out tags' → 'out body' in Overpass query)
- Fixed Eat & Drink empty (removed Google Places rating filter, show OSM food)
- Merged 8 duplicate destinations (Hepburn→Daylesford, Tidal River→Wilson's Prom etc)
- Added Dromana (Arthurs Seat + Hot Springs), Fort Nepean to Sorrento
- Tiered Overpass radius by distance from Melbourne CBD
- Generated descriptions for all activities/food via Claude Haiku
- Privacy page as standalone crawlable URL at /privacy
- Status page rewritten with region breakdown and cron health
- Weekly free tier limits monitor cron (/api/cron/limits)
- Fuel cron email removed — logged to status page instead
- Seasonal 'Have you seen' highlights (winter/autumn/spring/summer)
- Winter watercolour: dusty teal + warm rust
- PWA auto-reload on new version (skipWaiting + clientsClaim + auto-reload)
- Fixed 15 cluster images (Chicago/NYC skylines, African savanna → Victorian photos)
- Session logged to deployment_log table (git SHA: 613c650)

### Known issues / next session
1. **Add OSM + Wikipedia attribution to footer** (legally required by ODbL + CC-BY-SA)
2. **Re-enable accommodation wizard step** when data is confirmed good
3. **Inner Melbourne suburbs** — 2km radius now set, re-enrich to verify quality
4. **Business listing feature** — allow venues to claim/enhance listing (future Stripe)
5. **Domain** — unplannedescapes.com.au → Cloudflare free → Vercel
6. **OSM contributions** — add "Edit on OSM" link on activity/food cards (P3)
7. **"What's here" on destination cards** — show activity/food counts on landing page cards
8. **Region pages for SEO** — Option A (server-rendered HTML per region, Claude+Wikipedia content)
9. **Nearby places** section on destination view
10. **Remaining wrong cluster images** — GOR (still needs better shot), some others

## Cron Schedule
- `0 1 * * *`  — enrich places (11am AEST)
- `0 17 * * *` — fuel prices (3am AEST)
- `0 16 * * 0` — AI summaries (weekly Sunday)
- `0 23 * * 0` — limits monitor (Monday 9am AEST)

## File Map
- `api/cron/enrich.ts` — OSM enrichment (Overpass + Wikipedia + Claude descriptions)
- `api/cron/fuel.ts` — Service Victoria fuel prices
- `api/cron/summaries.ts` — AI destination summaries
- `api/cron/limits.ts` — Free tier usage monitor
- `api/status.ts` — HTML status dashboard
- `api/privacy.ts` — Standalone privacy/attribution page
- `src/data/victorianClusters.ts` — All destination/cluster static data + images
- `src/utils/season.ts` — Season detection + metadata (winter/autumn/spring/summer)
- `src/components/landing/LandingPage.tsx` — Landing page incl seasonal watercolour + highlights
- `supabase/schema.sql` — Full DB schema

## How to Resume a Session
1. Read this file
2. Check `vercel ls` for recent deployments
3. Check `/api/status` for data health
4. Check `git log --oneline -10` for recent changes
